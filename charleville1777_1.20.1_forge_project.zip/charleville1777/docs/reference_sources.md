# 参考与实现记录

- Nationaal Militair Museum, Model 1777 corrigé An 9: https://collectie.nmm.nl/nl/collectie/detail/315418/
- Military Heritage, French Model 1777 AN IX: https://militaryheritage.com/musket4.htm
- 1791 French infantry loading drill (translated transcription): https://militaryheritage.com/loading1777frenchmusket.htm

关键校核：历史资料给出全长约 1.52 m、枪管约 1.137 m、口径 17.5 mm；用户参考图标注 1.490 m，因此模型以参考图的 1.490 m 外观比例为主，并保留 An IX 的枪机、黄铜箍和套筒刺刀特征。装填由 1791 操典的十二段动作压缩成游戏中的 80 tick，依次触发火镰、纸壳、火药、通条和举枪阶段。

生图特效提示词：
“4×4 sprite atlas, transparent RGBA, successive orange-white-black-powder muzzle flash, gold flint sparks, grey-white black-powder smoke, no text, each sprite centered in its cell.”
