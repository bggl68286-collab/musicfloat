# 沙勒维尔 1777 型燧发枪（Minecraft 1.20.1 Forge）

这是按参考图制作的法国 Modèle 1777 corrigé An IX 游戏实现。参考尺寸：全长约 1,490–1,520 mm、枪管约 1,137 mm、口径 17.5 mm；枪身、枪托、三道箍、锁板、火镰、扳机护圈、通条和套筒刺刀都在文件 Charleville_1777_ANIX.bbmodel 中独立建模。模型比例按 Blockbench 的 Java Item 坐标保存，打开后可以继续细修。

## 手持方向

模型的局部 X 轴从枪托指向枪口。第一人称右手/左手都用沿视线前方的水平姿态：枪托靠近玩家，枪口朝前；右手握扳机护圈后方，左手握中箍前方。第三人称保持枪口前指，不会倒转。models/item/charleville_1777.json 和五个 reload_*.json 已写入 display 变换；这五个变体只做轻微抬枪/压枪，确保装填动作仍然拿在手中。

## 操作

- 物品初始为已装填。右键立即击发，命中视线 75 格内的实体造成 12 点伤害，并播放燧发枪声、火星、黑火药烟雾。
- 击发后右键进入约 4 秒的装填。动作分段对应 1791 年法军操典：开火镰、取纸壳、撕纸壳、撒火药、合火镰、倒入枪管、抽通条、压实、归还通条、举枪。中途松开右键会保留未装填状态。
- 装填完成后再次右键可开火。耐久 384，适合生存模式使用。
- 生图生成的 muzzle_vfx_atlas.png 是 4×4 的火焰、火星和烟雾素材；枪口闪焰已经注册为 Forge 自定义粒子并在枪口坐标生成；黑火药烟雾和火星同时用原版粒子补足。4×4 原图按单元尺寸 128 保存，便于继续扩展动画粒子。

## 构建和安装

1. 安装 Java 17（Forge 1.20.1 要求）和 Gradle 8.x。
2. 在此目录运行 gradle build。
3. 将 build/libs/charleville1777-1.20.1-1.0.0.jar 放入客户端和服务器的 mods 文件夹，并使用 Forge 47.x。
4. 若只想编辑模型，直接用 Blockbench 打开 .bbmodel；贴图在 src/main/resources/assets/charleville1777/textures/item/；模型资源使用 charleville_1777.json。音效资源为 OGG。

## 历史依据

- Nationaal Militair Museum：Model 1777 corrigé An 9 (https://collectie.nmm.nl/nl/collectie/detail/315418/)
- Military Heritage：French Model 1777 AN IX (https://militaryheritage.com/musket4.htm)
- 1791 法军装填操典 (https://militaryheritage.com/loading1777frenchmusket.htm)
