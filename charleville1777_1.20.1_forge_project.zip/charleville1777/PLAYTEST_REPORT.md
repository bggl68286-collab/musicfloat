# Charleville 1777 本地检查报告

日期：2026-10-13

## 已完成并通过

- JSON、Blockbench 模型、配方、音效索引和粒子索引全部可解析。
- Blockbench 模型包含 20 个部件，局部 X 轴从枪托指向枪口；第一/第三人称 display 变换均存在，左右手旋转保持枪口朝前。
- 装填状态机模拟通过：已装填右键击发；击发后 80 tick 装填；72 tick 标记完成；中途松开保持未装填。
- 生图特效图已切出 muzzle_flash、flint_sparks、blackpowder_smoke；muzzle_flash 已注册为 Forge 自定义粒子，生成点位于视线前方约 0.85 格的枪口位置。
- 5 个装填模型变体和 pulling/pull 属性均存在。
- 5 个 WAV 均为单声道 22050 Hz，声音索引与文件匹配。
- 服务端主类不再直接加载客户端粒子实现；客户端注册集中在 client 包。
- 本地 ZIP 完整性校验通过，当前本地包 SHA-256：da1d54d768e715be63b41d5e02edb585d73e7cf219ed647e75c9b2cf6cae8754。

## 尚未完成

当前环境没有可启动的 Minecraft 1.20.1 Forge 客户端，也无法访问 ForgeGradle/Minecraft 依赖仓库 `maven.minecraftforge.net`，所以没有进行真正的世界内启动、手持截图、碰撞命中和 FPS 测试。GitHub Actions 构建也暂不触发，等工程最终确认后再上传。

## 追加动作检查

- 右手 Y=+90、左手 Y=-90（镜像）后，局部枪口轴均指向远离镜头的 -Z；第三人称同样保持枪口前指。
- 击发加入 8 tick 冷却，避免按住右键连续速射。
- 枪口特效坐标改为玩家视线前方 0.85 格并下移 0.05 格；服务器通过 sendParticles 广播给所有客户端。
- 装填音效只由服务端触发一次，客户端保留烟雾/火星视觉阶段，避免多人环境重复播放声音。
