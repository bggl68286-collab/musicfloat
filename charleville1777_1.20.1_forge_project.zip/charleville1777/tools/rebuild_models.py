import json,os,shutil,math
root='/workspace/charleville1777'; asset=root+'/src/main/resources/assets/charleville1777'
bb=json.load(open(root+'/Charleville_1777_ANIX.bbmodel'))
# Canonical item texture name matches registry id.
old=asset+'/textures/item/charleville1777.png'; new=asset+'/textures/item/charleville_1777.png'
if os.path.exists(old): shutil.copy(old,new)
for i in range(1,6):
 p=asset+f'/textures/item/reload_{i}.png'
 if os.path.exists(old): shutil.copy(old,p)
# normalize 156-unit historical rifle into legal item-model range while retaining all named parts
scale_x=32/156

def mapped(v):
 x,y,z=v
 return [round(x*scale_x,3),round(4+(y-3)*8/12,3),round(4+(z-3)*8/12,3)]
faces={s:{'uv':[0,0,16,16],'texture':'#layer0'} for s in ['north','south','east','west','up','down']}
def elems(stage=0):
 out=[]
 rotations={
  'cock_hammer':[-22.5,-45,-45,-22.5,0],
  'frizzen':[-22.5,-45,-22.5,0,0],
  'frizzen_spring':[-22.5,-22.5,0,0,0],
  'ramrod':[0,22.5,45,45,0],
  'trigger':[22.5,22.5,0,0,0],
 }
 for e in bb['elements']:
  q={'name':e['name'],'from':mapped(e['from']),'to':mapped(e['to']),'faces':faces}
  if e['name'] in rotations and stage:
   angle=rotations[e['name']][stage-1]
   if angle: q['rotation']={'origin':mapped([20,9,8]),'axis':'z','angle':angle,'rescale':False}
  out.append(q)
 return out

def base(tex):
 return {'parent':'item/generated','textures':{'layer0':f'charleville1777:item/{tex}'},'elements':elems(), 'display':{
  'thirdperson_righthand':{'rotation':[0,90,0],'translation':[0,2,1],'scale':[0.32,0.32,0.32]},
  'thirdperson_lefthand':{'rotation':[0,-90,0],'translation':[0,2,1],'scale':[0.32,0.32,0.32]},
  'firstperson_righthand':{'rotation':[0,90,0],'translation':[0,1.5,2],'scale':[0.42,0.42,0.42]},
  'firstperson_lefthand':{'rotation':[0,-90,0],'translation':[0,1.5,2],'scale':[0.42,0.42,0.42]},
  'gui':{'rotation':[0,0,0],'translation':[0,0,0],'scale':[0.18,0.18,0.18]}}}
main=base('charleville_1777')
main['overrides']=[{'predicate':{'charleville1777:pulling':1,'charleville1777:pull':p},'model':f'charleville1777:item/reload_{i}'} for i,p in enumerate([.01,.2,.4,.6,.8],1)]
os.makedirs(asset+'/models/item',exist_ok=True)
json.dump(main,open(asset+'/models/item/charleville_1777.json','w'),indent=2)
# keep old file as compatibility alias but point it to the canonical model
json.dump({'parent':'charleville1777:item/charleville_1777'},open(asset+'/models/item/charleville1777.json','w'),indent=2)
for i in range(1,6):
 m=base(f'reload_{i}');m['elements']=elems(i);json.dump(m,open(asset+f'/models/item/reload_{i}.json','w'),indent=2)
print('generated canonical model with',len(main['elements']),'parts and 5 component animation stages')
