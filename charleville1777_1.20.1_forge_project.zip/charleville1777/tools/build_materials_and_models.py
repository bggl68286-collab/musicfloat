import json,os,shutil
from PIL import Image
root='/workspace/charleville1777'; asset=root+'/src/main/resources/assets/charleville1777'; tools=root+'/tools'
os.makedirs(asset+'/textures/item',exist_ok=True)
# Crop four generated vertical material panels into stable, tiled-friendly albedo sheets.
src=Image.open(tools+'/generated_material_atlas.png').convert('RGB')
W,H=src.size
mats=['wood','steel','brass','dark']
for i,n in enumerate(mats):
    crop=src.crop((i*W//4,0,(i+1)*W//4,H)).resize((256,64),Image.Resampling.LANCZOS)
    crop.save(asset+'/textures/item/'+n+'.png',optimize=True)
# remove old flat item texture copies from active resources; keep generated material sheets.
for n in ['charleville1777.png','charleville_1777.png']+[f'reload_{i}.png' for i in range(1,6)]:
    p=asset+'/textures/item/'+n
    if os.path.exists(p):os.remove(p)
bb=json.load(open(root+'/Charleville_1777_ANIX.bbmodel')); sx=32/156

def mapped(v):
 x,y,z=v;return [round(x*sx,3),round(4+(y-3)*8/12,3),round(4+(z-3)*8/12,3)]
def material(name):
 if any(k in name for k in ['stock','butt','comb','cheek','wrist','ramrod']):return 'wood'
 if any(k in name for k in ['band','swivel','butt_plate','muzzle_band']):return 'brass'
 if any(k in name for k in ['cock','frizzen','pan','trigger','side_plate','screw','guard','lug','sight','pipe']):return 'dark'
 return 'steel'
def elems(stage=0):
 out=[]; rotations={'cock_hammer':[-22.5,-45,-45,-22.5,0],'frizzen':[-22.5,-45,-22.5,0,0],'frizzen_spring':[-22.5,-22.5,0,0,0],'ramrod':[0,22.5,45,45,0],'trigger':[22.5,22.5,0,0,0]}
 for e in bb['elements']:
  faces={s:{'uv':[0,0,16,16],'texture':'#'+material(e['name'])} for s in ['north','south','east','west','up','down']}
  q={'name':e['name'],'from':mapped(e['from']),'to':mapped(e['to']),'faces':faces}
  if e['name'] in rotations and stage:
   a=rotations[e['name']][stage-1]
   if a:q['rotation']={'origin':mapped([20,9,8]),'axis':'z','angle':a,'rescale':False}
  out.append(q)
 return out
def model(stage=0):
 tex={n:f'charleville1777:item/{n}' for n in ['wood','steel','brass','dark']}
 tex['layer0']='charleville1777:item/wood'
 return {'parent':'item/generated','textures':tex,'elements':elems(stage),'display':{
  'thirdperson_righthand':{'rotation':[0,90,0],'translation':[0,2,1],'scale':[.32,.32,.32]},'thirdperson_lefthand':{'rotation':[0,-90,0],'translation':[0,2,1],'scale':[.32,.32,.32]},
  'firstperson_righthand':{'rotation':[0,90,0],'translation':[0,1.5,2],'scale':[.42,.42,.42]},'firstperson_lefthand':{'rotation':[0,-90,0],'translation':[0,1.5,2],'scale':[.42,.42,.42]},'gui':{'scale':[.18,.18,.18]}}}
main=model();main['overrides']=[{'predicate':{'charleville1777:pulling':1,'charleville1777:pull':p},'model':f'charleville1777:item/reload_{i}'} for i,p in enumerate([.01,.2,.4,.6,.8],1)]
os.makedirs(asset+'/models/item',exist_ok=True)
json.dump(main,open(asset+'/models/item/charleville_1777.json','w'),indent=2)
for i in range(1,6):json.dump(model(i),open(asset+f'/models/item/reload_{i}.json','w'),indent=2)
print('MODEL REBUILT',len(main['elements']),'parts','materials',mats)
