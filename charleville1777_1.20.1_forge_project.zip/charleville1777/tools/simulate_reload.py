from dataclasses import dataclass
@dataclass
class Gun:
 loaded: bool=True
 cooldown: int=0
 def right_click(self):
  if self.cooldown: return 'blocked'
  if self.loaded:
   self.loaded=False; self.cooldown=8; return 'fire'
  return 'reload_start'
 def tick_reload(self,t):
  events={8:'frizzen_click',30:'cartridge',52:'prime',64:'ramrod',72:'loaded'}
  if t==72:self.loaded=True
  return events.get(t)
 def release(self,t):
  if t<72:self.loaded=False

g=Gun(); assert g.right_click()=='fire' and not g.loaded and g.cooldown==8
assert g.right_click()=='blocked'
g.cooldown=0; assert g.right_click()=='reload_start'
for t in range(1,81):g.tick_reload(t)
assert g.loaded and g.right_click()=='fire'
g=Gun(False); assert g.right_click()=='reload_start'
for t in range(1,41):g.tick_reload(t)
g.release(40); assert not g.loaded
print('GAMEPLAY SIM PASS: fire -> cooldown -> reload stages -> loaded; early release stays unloaded')
