package com.napoleon.charleville;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

@Mod(Charleville1777.MODID)
public class Charleville1777 {
    public static final String MODID = "charleville1777";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);
    public static final DeferredRegister<net.minecraft.core.particles.ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, MODID);
    public static final RegistryObject<SimpleParticleType> MUZZLE_FLASH = PARTICLES.register("muzzle_flash", () -> new SimpleParticleType(false));
    public static final RegistryObject<SoundEvent> MUSKET_FIRE = sound("musket_fire");
    public static final RegistryObject<SoundEvent> FLINT_CLICK = sound("flint_click");
    public static final RegistryObject<SoundEvent> RAMROD = sound("ramrod");
    public static final RegistryObject<SoundEvent> RELOAD_START = sound("reload_start");
    public static final RegistryObject<SoundEvent> RELOAD_COMPLETE = sound("reload_complete");
    public static final RegistryObject<Item> CHARLEVILLE = ITEMS.register("charleville_1777", () -> new CharlevilleItem(new Item.Properties().stacksTo(1).durability(384)));
    private static RegistryObject<SoundEvent> sound(String id) {
        return SOUNDS.register(id, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, id)));
    }
    public Charleville1777() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus); SOUNDS.register(bus); PARTICLES.register(bus);
        bus.addListener(this::creativeTab);
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.napoleon.charleville.client.ClientOnly.init(bus));
    }
    private void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) e.accept(CHARLEVILLE);
    }
    // Client-only registrations live in client.ClientOnly to keep dedicated servers safe.
    public static class CharlevilleItem extends Item {
        public static final int RELOAD_TICKS = 80;
        public CharlevilleItem(Properties p) { super(p); }
        private static boolean loaded(ItemStack s) { return !s.hasTag() || !s.getTag().contains("Loaded") || s.getTag().getBoolean("Loaded"); }
        private static void setLoaded(ItemStack s, boolean v) { s.getOrCreateTag().putBoolean("Loaded", v); }
        @Override public int getUseDuration(ItemStack s) { return RELOAD_TICKS; }
        @Override public UseAnim getUseAnimation(ItemStack s) { return UseAnim.BOW; }
        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack=player.getItemInHand(hand);
            if (loaded(stack)) { if (!level.isClientSide) fire(level, player, stack, hand); player.swing(hand, true); player.getCooldowns().addCooldown(this, 8); return InteractionResultHolder.sidedSuccess(stack, level.isClientSide); }
            level.playSound(player, player.blockPosition(), RELOAD_START.get(), player.getSoundSource(), .8f, 1.0f);
            player.startUsingItem(hand); return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        @Override public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
            if (!(entity instanceof Player p)) return;
            int elapsed=RELOAD_TICKS-remaining;
            if (!level.isClientSide && (elapsed==8 || elapsed==30 || elapsed==52)) level.playSound(null,p.blockPosition(), FLINT_CLICK.get(), p.getSoundSource(),.35f,1.0f+(elapsed/200f));
            if (!level.isClientSide && elapsed==64) level.playSound(null,p.blockPosition(), RAMROD.get(), p.getSoundSource(),.5f,.85f);
            if (elapsed==72 && !level.isClientSide) { setLoaded(stack,true); level.playSound(null,p.blockPosition(),RELOAD_COMPLETE.get(),p.getSoundSource(),.8f,1.0f); }
            if (level.isClientSide && elapsed>0) {
                if (elapsed%8==0) level.addParticle(ParticleTypes.SMOKE,p.getX(),p.getEyeY(),p.getZ(),0,0.01,0);
                if (elapsed==28||elapsed==60) level.addParticle(ParticleTypes.CRIT,p.getX(),p.getEyeY(),p.getZ(),0,0,0);
            }
        }
        @Override public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int remaining) {
            if (!(entity instanceof Player p)) return;
            if (RELOAD_TICKS-remaining < 72 && !level.isClientSide) setLoaded(stack,false);
        }
        private static void fire(Level level, Player p, ItemStack stack, InteractionHand hand) {
            setLoaded(stack,false); stack.hurtAndBreak(1,p,pl->pl.broadcastBreakEvent(hand));
            level.playSound(null,p.blockPosition(),MUSKET_FIRE.get(),p.getSoundSource(),1.4f,.9f+(p.getRandom().nextFloat()*.2f));
            var muzzle=p.getEyePosition().add(p.getViewVector(1).scale(.85)).add(0,-.05,0);
            if (level instanceof ServerLevel server) {
                server.sendParticles(MUZZLE_FLASH.get(),muzzle.x,muzzle.y,muzzle.z,1,0,0,0,0);
                server.sendParticles(ParticleTypes.SMOKE,muzzle.x,muzzle.y,muzzle.z,18,.08,.08,.08,.02);
                server.sendParticles(ParticleTypes.FLAME,muzzle.x,muzzle.y,muzzle.z,8,.15,.12,.15,.02);
            }
            var start=p.getEyePosition(); var end=start.add(p.getViewVector(1).scale(75));
            BlockHitResult block=level.clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
            double max=block.getType()==HitResult.Type.MISS?75:start.distanceTo(block.getLocation());
            AABB box=p.getBoundingBox().expandTowards(p.getViewVector(1).scale(max)).inflate(1.0);
            List<Entity> hits=level.getEntities(p,box,e->e.isPickable()&&!e.isSpectator());
            Entity best=null; double bd=max;
            for(Entity e:hits){var h=e.getBoundingBox().inflate(.2).clip(start,end);if(h.isPresent()&&start.distanceTo(h.get())<bd){bd=start.distanceTo(h.get());best=e;}}
            if(best!=null) best.hurt(p.damageSources().playerAttack(p),12.0f);
        }
    }
}
