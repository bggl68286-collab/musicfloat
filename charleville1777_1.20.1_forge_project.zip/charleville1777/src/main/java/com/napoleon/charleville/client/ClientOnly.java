package com.napoleon.charleville.client;

import com.napoleon.charleville.Charleville1777;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

public final class ClientOnly {
    private ClientOnly() {}
    public static void init(IEventBus bus) {
        bus.addListener(ClientOnly::setup);
        bus.addListener(ClientOnly::registerParticleProviders);
    }
    private static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        // SpriteSet is populated after particle atlas reload; registering here avoids the empty-list crash.
        event.registerSpriteSet(Charleville1777.MUZZLE_FLASH.get(), MuzzleFlashParticle.Provider::new);
        event.registerSpriteSet(Charleville1777.FLINT_SPARKS.get(), MuzzleFlashParticle.Provider::new);
        event.registerSpriteSet(Charleville1777.BLACKPOWDER_SMOKE.get(), MuzzleFlashParticle.Provider::new);
    }
    private static void setup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            ItemProperties.register(Charleville1777.CHARLEVILLE.get(), new ResourceLocation(Charleville1777.MODID, "pulling"),
                    (stack, level, entity, seed) -> entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0f : 0.0f);
            ItemProperties.register(Charleville1777.CHARLEVILLE.get(), new ResourceLocation(Charleville1777.MODID, "pull"),
                    (stack, level, entity, seed) -> {
                        if (entity == null || !entity.isUsingItem() || entity.getUseItem() != stack) return 0.0f;
                        float used = stack.getUseDuration() - entity.getUseItemRemainingTicks();
                        return Math.min(1.0f, used / (float) stack.getUseDuration());
                    });
        });
    }
}
