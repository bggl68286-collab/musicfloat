#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null; then echo '请先安装 Gradle 8.x 和 Java 17'; exit 1; fi
mkdir -p .gradle-home .gradle-tmp
GRADLE_USER_HOME="${GRADLE_USER_HOME:-$PWD/.gradle-home}" TMPDIR="${TMPDIR:-$PWD/.gradle-tmp}" gradle --no-daemon build
