package dev.musicfloat.napoleoniccannon;

import dev.musicfloat.napoleoniccannon.item.HandCannonItem;
import dev.musicfloat.napoleoniccannon.entity.Cannonball;
import dev.musicfloat.napoleoniccannon.network.CannonNetwork;
import dev.musicfloat.napoleoniccannon.particle.CannonParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.*;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.registries.*;
import java.util.*;

@Mod(NapoleonicCannon.MOD_ID)
public final class NapoleonicCannon {
    public static final String MOD_ID="napoleonic_cannon";
    public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS,MOD_ID);
    public static final RegistryObject<Item> CANNON=ITEMS.register("hand_cannon",HandCannonItem::new);
    public static final RegistryObject<Item> ROUND_SHOT=ITEMS.register("round_shot",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> CANISTER_SHOT=ITEMS.register("canister_shot",()->new Item(new Item.Properties()));
    public static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(ForgeRegistries.ENTITY_TYPES,MOD_ID);
    public static final RegistryObject<EntityType<Cannonball>> BALL=ENTITIES.register("cannonball",()->EntityType.Builder.<Cannonball>of(Cannonball::new,MobCategory.MISC).sized(.24f,.24f).clientTrackingRange(96).updateInterval(1).build(MOD_ID+":cannonball"));
    public static final DeferredRegister<ParticleType<?>> PARTICLES=DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES,MOD_ID);
    public static final RegistryObject<ParticleType<CannonParticleOptions>> FX=PARTICLES.register("cannon_fx",()->new ParticleType<>(false,CannonParticleOptions.DESERIALIZER){
        @Override public com.mojang.serialization.Codec<CannonParticleOptions> codec(){return CannonParticleOptions.CODEC;}
    });
    public static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(ForgeRegistries.SOUND_EVENTS,MOD_ID);
    public static final Map<String,RegistryObject<SoundEvent>> SOUND=new LinkedHashMap<>();
    static {for(String name:List.of("sponge","powder","insert","ram","aim","ignite","report","return","impact"))SOUND.put(name,SOUNDS.register(name,()->SoundEvent.createVariableRangeEvent(new ResourceLocation(MOD_ID,name))));}
    public NapoleonicCannon(){
        var bus=FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);ENTITIES.register(bus);PARTICLES.register(bus);SOUNDS.register(bus);
        bus.addListener(this::tab);ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER,CannonConfig.SPEC);CannonNetwork.register();
    }
    private void tab(BuildCreativeModeTabContentsEvent e){if(e.getTabKey()==CreativeModeTabs.COMBAT){e.accept(CANNON);e.accept(ROUND_SHOT);e.accept(CANISTER_SHOT);}}
}
