package dev.musicfloat.napoleoniccannon.client;
import dev.musicfloat.napoleoniccannon.NapoleonicCannon;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.List;
@Mod.EventBusSubscriber(modid=NapoleonicCannon.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class ClientRegistration {
    public static final List<String> PARTS=List.of("carriage","barrel","wheel_left","wheel_right","ramrod","ball","powder","canister","wick");
    @SubscribeEvent public static void particles(RegisterParticleProvidersEvent e){e.registerSpriteSet(NapoleonicCannon.FX.get(),CannonParticle.Provider::new);}
    @SubscribeEvent public static void models(ModelEvent.RegisterAdditional e){for(String part:PARTS)e.register(new ResourceLocation(NapoleonicCannon.MOD_ID,"item/"+part));}
    @SubscribeEvent public static void entities(EntityRenderersEvent.RegisterRenderers e){e.registerEntityRenderer(NapoleonicCannon.BALL.get(),CannonballRenderer::new);}
    private ClientRegistration(){}
}
