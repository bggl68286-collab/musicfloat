package dev.musicfloat.napoleoniccannon;
import net.minecraftforge.common.ForgeConfigSpec;
public final class CannonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue ROUND_DAMAGE,PELLET_DAMAGE,SPEED;
    public static final ForgeConfigSpec.IntValue PELLETS;
    public static final ForgeConfigSpec.BooleanValue DAMAGE_PLAYERS,SOUND;
    static{var b=new ForgeConfigSpec.Builder();
        ROUND_DAMAGE=b.defineInRange("roundShotDamage",78d,1,500);
        PELLET_DAMAGE=b.defineInRange("canisterPelletDamage",8d,1,100);
        PELLETS=b.defineInRange("canisterPellets",14,3,24);
        SPEED=b.defineInRange("projectileSpeed",4.2d,1,6);
        DAMAGE_PLAYERS=b.define("damagePlayers",false);SOUND=b.define("soundEffects",true);SPEC=b.build();}
    private CannonConfig(){}
}
